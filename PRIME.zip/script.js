/* ========== EDIT YOUR CLAN DETAILS HERE ========== */
const CONFIG = {
  name: "Prime Kerala",
  tag: "#2JYR2Y2VP",
  motto: "Clashing at our PRIME",
  clanLink: "https://link.clashofclans.com/en?action=OpenClanProfile&tag=2JYR2Y2VP",
  discordLink: "https://discord.gg/4XWKHEgx",
  minTh: "13",
  minTrophies: "3000",
  location: "India / Kerala",
  schedule: "Wars every Monday to sunday",
  type: "WAR / SOCIAL / HYBRID",
  language: "English, Malayalam",
  members: "48/50",
  clanLevel: "10",
  winStreak: "STREAK",
  capitalLevel: "8",
  workerUrl: "https://rough-hat-53e6.ooyqyyiywp.workers.dev",
  announcement: "CWL starts soon! Make sure your war opt-in is ON.",
  events: [
    { label: "Next Clan War",   date: "2026-11-05T20:00:00+05:30" },
    { label: "Clan Games",      date: "2026-11-22T10:00:00+05:30" },
    { label: "Raid Weekend",    date: "2026-11-06T10:00:00+05:30" }
  ],
};
/* ================================================= */

// Fill text from CONFIG
document.title = CONFIG.name + " | Clash of Clans Clan";
document.querySelectorAll("[data-cfg]").forEach(el => {
  const v = CONFIG[el.dataset.cfg];
  if (v !== undefined) el.textContent = v;
});

// Fill links
document.querySelectorAll("[data-link]").forEach(a => {
  const v = CONFIG[a.dataset.link];
  if (/^https?:\/\//.test(v)) {
    a.href = v;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
  } else {
    a.href = "#join";
  }
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Mobile menu
const burger = document.getElementById("burger");
const menu = document.getElementById("menu");
function setMenu(open) {
  menu.classList.toggle("open", open);
  burger.setAttribute("aria-expanded", String(open));
  burger.textContent = open ? "✕" : "☰";
}
burger.addEventListener("click", () => setMenu(!menu.classList.contains("open")));
document.addEventListener("keydown", e => { if (e.key === "Escape") setMenu(false); });

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener("click", e => {
    const target = document.querySelector(a.getAttribute("href"));
    if (!target) return;
    e.preventDefault();
    const calm = matchMedia("(prefers-reduced-motion: reduce)").matches;
    target.scrollIntoView({ behavior: calm ? "auto" : "smooth" });
    history.replaceState(null, "", a.getAttribute("href"));
    setMenu(false);
  });
});

// "War Ready?" checklist
const boxes = document.querySelectorAll(".check input");
const out = document.getElementById("chk-out");
function updateChecklist() {
  const n = [...boxes].filter(b => b.checked).length;
  out.textContent = n === boxes.length ? "⚔️ You are war ready!" : n + " of " + boxes.length + " ready";
}
boxes.forEach(b => b.addEventListener("change", updateChecklist));

// Announcement bar
(function () {
  const bar = document.getElementById("announce");
  if (!bar || !CONFIG.announcement) return;
  document.getElementById("announce-text").textContent = "📢 " + CONFIG.announcement;
  bar.hidden = false;
  document.getElementById("announce-x").addEventListener("click", () => { bar.hidden = true; });
})();

// Countdown timers
(function () {
  const box = document.getElementById("countdowns");
  if (!box) return;
  const items = CONFIG.events.map(ev => {
    const card = document.createElement("div");
    card.className = "card stat cd";
    const label = document.createElement("span");
    label.textContent = ev.label;
    const time = document.createElement("strong");
    time.className = "time";
    const small = document.createElement("small");
    small.textContent = new Date(ev.date).toLocaleString();
    card.append(label, time, small);
    box.appendChild(card);
    return { ev, time };
  });
  function tick() {
    items.forEach(({ ev, time }) => {
      const ms = new Date(ev.date) - new Date();
      if (isNaN(ms)) { time.textContent = "Set date"; return; }
      if (ms <= 0) { time.textContent = "Started!"; return; }
      const s = Math.floor(ms / 1000);
      time.textContent = Math.floor(s / 86400) + "d " + Math.floor(s % 86400 / 3600) + "h " +
        Math.floor(s % 3600 / 60) + "m " + (s % 60) + "s";
    });
  }
  tick();
  setInterval(tick, 1000);
})();

// Leadership: Leader and Co-leaders from the live clan data
function renderLeaders(list) {
  const section = document.querySelector("#leadership .wrap");
  if (!section) return;
  [...section.children].forEach(c => { if (c.tagName !== "H2") c.remove(); });
  const groups = [
    { role: "leader", title: "Leader" },
    { role: "coLeader", title: "Co-leaders" }
  ];
  const ROLE = { leader: "Leader", coLeader: "Co-leader" };
  groups.forEach(g => {
    const people = list
      .filter(m => m.role === g.role)
      .sort((a, b) => (b.trophies || 0) - (a.trophies || 0));
    if (!people.length) return;
    const h = document.createElement("h3");
    h.style.cssText = "margin:36px 0 0;color:var(--gold);font-size:1.4rem";
    h.textContent = g.title + " (" + people.length + ")";
    section.appendChild(h);
    const wrap = document.createElement("div");
    wrap.className = "grid g4";
    people.forEach(m => {
      const card = document.createElement("article");
      card.className = "card lead-card";
      const av = document.createElement("div");
      av.className = "av";
      av.textContent = m.name.replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase() || "?";
      const name = document.createElement("h3");
      name.textContent = m.name;
      const role = document.createElement("span");
      role.className = "role";
      role.textContent = ROLE[m.role];
      const info = document.createElement("p");
      info.textContent = "Town Hall " + m.townHallLevel + " · " + m.trophies + " trophies";
      card.append(av, name, role, info);
      wrap.appendChild(card);
    });
    section.appendChild(wrap);
  });
}

// Live clan data + sortable members table
(function () {
  const status = document.getElementById("live-status");
  const body = document.getElementById("mbody");
  if (!body) return;
  const ROLE = { leader: "Leader", coLeader: "Co-leader", admin: "Elder", member: "Member" };
  const ROLE_RANK = { leader: 4, coLeader: 3, admin: 2, member: 1 };
  let members = [], key = "trophies", dir = -1;

  function value(m, k) { return k === "role" ? ROLE_RANK[m.role] || 0 : m[k] || 0; }

  function render() {
    members.sort((a, b) => (value(a, key) - value(b, key)) * dir);
    body.textContent = "";
    members.forEach((m, i) => {
      const tr = document.createElement("tr");
      [i + 1, m.name, ROLE[m.role] || m.role, m.townHallLevel, m.trophies, m.donations].forEach(v => {
        const td = document.createElement("td");
        td.textContent = v;
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
    document.querySelectorAll("th[aria-sort]").forEach(th => {
      const b = th.querySelector("button");
      th.setAttribute("aria-sort", b.dataset.sort === key ? (dir === 1 ? "ascending" : "descending") : "none");
    });
  }

  document.querySelectorAll("[data-sort]").forEach(btn => {
    btn.addEventListener("click", () => {
      const k = btn.dataset.sort;
      dir = (k === key) ? -dir : -1;
      key = k;
      render();
    });
  });

  function setText(name, v) {
    if (v === undefined || v === null) return;
    document.querySelectorAll('[data-cfg="' + name + '"]').forEach(el => { el.textContent = v; });
  }

  async function load() {
    if (!/^https?:\/\//.test(CONFIG.workerUrl)) {
      status.textContent = "Live data is off. Add your Worker address to CONFIG (workerUrl).";
      return;
    }
    try {
      const res = await fetch(CONFIG.workerUrl);
      if (!res.ok) throw new Error("bad response");
      const d = await res.json();
      if (d.error) throw new Error(d.error);
      setText("members", d.members + "/50");
      setText("clanLevel", d.clanLevel);
      setText("winStreak", d.warWinStreak);
      setText("capitalLevel", d.capitalHallLevel);
      members = d.memberList || [];
      renderLeaders(members);
      render();
      status.textContent = "Live from the game · updated " + new Date().toLocaleTimeString();
    } catch (e) {
      status.textContent = "Could not load live data right now. Please try again later.";
    }
  }
  load();
  setInterval(load, 5 * 60 * 1000);
})();

// Slide view: each section is a slide
(function () {
  const main = document.getElementById("main");
  if (!main) return;
  const slides = [...main.querySelectorAll(":scope > section")];
  if (!slides.length) return;
  const last = slides.length - 1;
  const calm = matchMedia("(prefers-reduced-motion: reduce)").matches;

  // footer goes inside the last slide
  const foot = document.querySelector("footer.foot");
  if (foot) slides[last].appendChild(foot);

  // arrow buttons + dots
  const prev = document.createElement("button");
  prev.id = "prev"; prev.className = "slide-btn"; prev.textContent = "‹"; prev.setAttribute("aria-label", "Previous slide");
  const next = document.createElement("button");
  next.id = "next"; next.className = "slide-btn"; next.textContent = "›"; next.setAttribute("aria-label", "Next slide");
  const dotBox = document.createElement("div");
  dotBox.id = "dots";
  const dots = slides.map((s, i) => {
    const d = document.createElement("button");
    d.className = "dot";
    const h = s.querySelector("h2");
    d.setAttribute("aria-label", "Go to " + (h ? h.textContent : "Home"));
    d.addEventListener("click", () => go(i));
    dotBox.appendChild(d);
    return d;
  });
  document.body.append(prev, next, dotBox);

  let cur = 0;
  function go(i, instant) {
    i = Math.max(0, Math.min(last, i));
    main.scrollTo({ left: i * main.clientWidth, behavior: (calm || instant) ? "instant" : "smooth" });
  }
  function update() {
    cur = Math.round(main.scrollLeft / main.clientWidth);
    dots.forEach((d, i) => d.setAttribute("aria-current", String(i === cur)));
    prev.disabled = cur === 0;
    next.disabled = cur === last;
  }
  prev.addEventListener("click", () => go(cur - 1));
  next.addEventListener("click", () => go(cur + 1));
  main.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", () => { go(cur, true); update(); });

  // menu links jump to the matching slide
  document.addEventListener("click", e => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const t = document.querySelector(a.getAttribute("href"));
    const i = slides.indexOf(t);
    if (i < 0) return;
    e.preventDefault();
    e.stopPropagation();
    go(i);
    setMenu(false);
  }, true);

  // keyboard arrows
  document.addEventListener("keydown", e => {
    const tag = e.target.tagName;
    if (tag === "INPUT" || tag === "SUMMARY") return;
    if (e.key === "ArrowRight") go(cur + 1);
    if (e.key === "ArrowLeft") go(cur - 1);
  });

  // open the slide named in the link, if any
  const start = slides.indexOf(document.querySelector(location.hash || "#none"));
  if (start > 0) go(start, true);
  update();
})();

// Home page upgrade: badge, top players, swipe hint
(function () {
  const left = document.querySelector("#home .hero-in > div");
  const h1 = left && left.querySelector("h1");
  if (!left || !h1) return;

  const badge = document.createElement("p");
  badge.className = "badge";
  badge.textContent = "⚔️ Now recruiting";
  left.insertBefore(badge, h1);

  const top = document.createElement("div");
  top.className = "top";
  top.hidden = true;
  const title = document.createElement("h3");
  title.textContent = "🏆 Top players";
  const list = document.createElement("div");
  list.className = "top-list";
  top.append(title, list);
  left.appendChild(top);

  const hint = document.createElement("p");
  hint.className = "hint";
  hint.textContent = "Swipe or use the arrows to explore ›";
  left.appendChild(hint);

  if (!/^https?:\/\//.test(CONFIG.workerUrl)) return;
  fetch(CONFIG.workerUrl)
    .then(r => r.json())
    .then(d => {
      if (d.error) return;
      const spots = 50 - d.members;
      badge.textContent = spots > 0
        ? "⚔️ Now recruiting · " + spots + " open spot" + (spots === 1 ? "" : "s")
        : "🛡️ Clan is full right now";
      const medals = ["🥇", "🥈", "🥉"];
      (d.memberList || [])
        .slice()
        .sort((a, b) => (b.trophies || 0) - (a.trophies || 0))
        .slice(0, 3)
        .forEach((m, i) => {
          const card = document.createElement("div");
          card.className = "top-card";
          const name = document.createElement("strong");
          name.textContent = medals[i] + " " + m.name;
          const info = document.createElement("span");
          info.textContent = m.trophies + " trophies";
          card.append(name, info);
          list.appendChild(card);
        });
      top.hidden = list.children.length === 0;
    })
    .catch(() => {});
})();